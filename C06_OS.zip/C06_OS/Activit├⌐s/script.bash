#!/bin/bash
a=1
while ((a <= 10)) 
do
  printf -v suffix "%04d" "$a"
  # Début partie à modifier
  echo Numero$suffix   # Affiche dans le terminal NumeroXXXX -- Inspirez-vous pour créer votre arborescence.





  # Fin partie à modifier
  ((a += 1))
done

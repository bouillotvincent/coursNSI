#!/bin/bash
a=1
while ((a <= 400))
do
  printf -v suffix "%04d" "$a"
  # Début partie à modifier






  # Fin partie à modifier
  ((a += 1))
done

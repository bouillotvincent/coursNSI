#!/bin/bash
a=1
while ((a <= 400))
do
  printf -v suffix "%04d" "$a"
  mkdir Employe$suffix
  cd Employe$suffix
  mkdir Administratif
  mkdir Technique
  mkdir Autre
  cd ..
  ((a += 1))
done
